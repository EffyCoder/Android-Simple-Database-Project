package com.example.simpledbproject.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.simpledbproject.R;
import com.example.simpledbproject.activity.DatabaseHandler;
import com.example.simpledbproject.model.MusicInfo;

import java.util.List;

/**
 * Created by ANV27 on 07-11-2017.
 */

public class SongsAdapter extends RecyclerView.Adapter<SongsAdapter.SongHolder> {

    int listSize;
    Context mContext;
    List<MusicInfo> musicInfoList;
    public SongsAdapter(Context context, List<MusicInfo> songsList)
    {
        mContext = context;
        listSize = songsList.size();
        Log.e("Tag",String.valueOf(listSize));
        musicInfoList = songsList;
    }


    @Override
    public SongHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.list_item,parent,false);
        return new SongHolder(v);
    }

    @Override
    public void onBindViewHolder(SongHolder holder, int position) {
        final int pos = position;
        final MusicInfo m = musicInfoList.get(position);
        holder.songName.setText(m.getSongName());
        holder.artist.setText(m.getArtist());
        holder.genre.setText(m.getGenre());
        holder.deleteSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHandler db = new DatabaseHandler(mContext);
                db.deleteSongInfo(m);
                musicInfoList.remove(m);
                listSize--;
                notifyItemRemoved(pos);
            }
        });
    }

    @Override
    public int getItemCount() {
        System.out.println(listSize);
        return listSize;
    }

    class SongHolder extends RecyclerView.ViewHolder
    {
        TextView songName,genre,artist;
        Button deleteSong;

        public SongHolder(View itemView) {
            super(itemView);
            artist = itemView.findViewById(R.id.artist);
            genre = itemView.findViewById(R.id.genre);
            songName = itemView.findViewById(R.id.song_name);
            deleteSong = itemView.findViewById(R.id.delete);
        }
    }
}
