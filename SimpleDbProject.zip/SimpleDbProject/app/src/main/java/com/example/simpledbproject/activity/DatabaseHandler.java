package com.example.simpledbproject.activity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.simpledbproject.model.MusicInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ANV27 on 06-11-2017.
 */

public class DatabaseHandler extends SQLiteOpenHelper {

    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "songManager";


    // Songs table name
    private static final String TABLE_SONGS = "songs";

    // Contacts Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_ARTIST = "artist";
    private static final String KEY_GENRE = "genre";


    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    //CREATING TABLES
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_SONGS_TABLE = "CREATE TABLE "+TABLE_SONGS+" ("+KEY_ID+" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"+ KEY_NAME + " TEXT," +
                KEY_ARTIST + " TEXT," + KEY_GENRE + " TEXT)";
        sqLiteDatabase.execSQL(CREATE_SONGS_TABLE);

    }
//UPGRADING DATABASE
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_SONGS);
        // Create tables again
        onCreate(sqLiteDatabase);
    }



    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */


    //Adding new song
    void addSong(MusicInfo musicInfo)
    {
      SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_NAME, musicInfo.getSongName());
        contentValues.put(KEY_GENRE, musicInfo.getGenre());
        contentValues.put(KEY_ARTIST, musicInfo.getArtist());


        //inserting a row

        db.insert(TABLE_SONGS,null, contentValues);
        db.close();
    }

    //getting single song

    MusicInfo getSongInfo(int id)
    {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_SONGS, new String[] {KEY_ID,KEY_NAME,KEY_ARTIST,KEY_GENRE},
                KEY_ID+"=?",new String[]{String.valueOf(id)},null,null,null,null);

        MusicInfo songInfo = null;

        if(cursor!=null) {
            cursor.moveToFirst();


            songInfo = new MusicInfo(Integer.parseInt(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3));


            cursor.close();
        }
        return  songInfo;

    }

    //get all songs

    public List<MusicInfo> getAllSongs()
    {
        List<MusicInfo> songsList = new ArrayList<>();


        //SELECTS ALL SONGS QUERY

        String SELECT_ALL_SONGS = "SELECT * FROM " + TABLE_SONGS;


        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        Cursor cursor = sqLiteDatabase.rawQuery(SELECT_ALL_SONGS,null);

        // Looping through all the rows returned by query and adding it to the list

        if(cursor.moveToFirst()) {
            do {
                MusicInfo musicInfo = new MusicInfo();
                musicInfo.setMusicId(Integer.parseInt(cursor.getString(0)));
                musicInfo.setSongName(cursor.getString(1));
                musicInfo.setArtist(cursor.getString(2));
                musicInfo.setGenre(cursor.getString(3));
                songsList.add(musicInfo);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return songsList;
    }

    // Updating song info

    public int updateSongInfo(MusicInfo song){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_NAME,song.getSongName());
        contentValues.put(KEY_ARTIST,song.getArtist());
        contentValues.put(KEY_GENRE,song.getGenre());

        return db.update(TABLE_SONGS,contentValues,KEY_ID+" = ?",new String[]{String.valueOf(song.getMusicId())});

    }

    // Deleting song info

    public void deleteSongInfo(MusicInfo song){
        SQLiteDatabase db = this.getWritableDatabase();
        System.out.println(String.valueOf(song.getMusicId()));
        db.delete(TABLE_SONGS,KEY_ID + " = ?",new String[]{String.valueOf(song.getMusicId())});
        db.close();
    }

    // Getting count of songs
    public int getNumberOfSongs()
    {
        String countQuery = "SELECT * FROM " + TABLE_SONGS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        // return no. of rows
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count;
    }


}
