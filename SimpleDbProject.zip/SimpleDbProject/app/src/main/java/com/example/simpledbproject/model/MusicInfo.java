package com.example.simpledbproject.model;

/**
 * Created by ANV27 on 06-11-2017.
 */

public class MusicInfo {
    private int musicId;

    private  String songName, artist, genre;

    public MusicInfo(int id, String name, String artist, String genre){
        this.musicId = id;
        this.songName = name;
        this.artist = artist;
        this.genre = genre;
    }

    public MusicInfo(String name, String artist, String genre){
        this.songName = name;
        this.artist = artist;
        this.genre = genre;
    }


    public MusicInfo() {
    }

    public int getMusicId() {
        return musicId;
    }

    public void setMusicId(int musicId) {
        this.musicId = musicId;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }



}
