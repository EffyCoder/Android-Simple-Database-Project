package com.example.simpledbproject.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.simpledbproject.R;
import com.example.simpledbproject.adapter.SongsAdapter;
import com.example.simpledbproject.model.MusicInfo;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    SongsAdapter songsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.songs_list);



        Button addSongToList = findViewById(R.id.add_song_to_list);
        addSongToList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),AddSong.class);
                startActivity(i);
            }
        });
        doDatabaseTask();
    }


    private void doDatabaseTask() {

        DatabaseHandler dbHandler = new DatabaseHandler(this);

        List<MusicInfo> songs = dbHandler.getAllSongs();
        TextView NoSongsYet = findViewById(R.id.no_songs_yet);
        if(songs.size()==0)
        {
            NoSongsYet.setVisibility(View.GONE);
        }
        else
        {
            NoSongsYet.setVisibility(View.VISIBLE);
        }
        songsAdapter = new SongsAdapter(this,songs);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(songsAdapter);

        System.out.println(dbHandler.getNumberOfSongs() + songs.toString());
        dbHandler.close();
    }

    @Override
    protected void onResume() {
        super.onResume();
        doDatabaseTask();
    }
}
