package com.example.simpledbproject.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.simpledbproject.R;
import com.example.simpledbproject.model.MusicInfo;

public class AddSong extends AppCompatActivity {

    EditText songnameEt,artistEt,genreEt;
    String songname,artist,genre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_song);
        songnameEt = findViewById(R.id.song_name);
        artistEt = findViewById(R.id.artist);
        genreEt = findViewById(R.id.genre);



        Button addSong = findViewById(R.id.add_song);
        addSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                songname = songnameEt.getText().toString();
                artist = artistEt.getText().toString();
                genre = genreEt.getText().toString();

                if(songname.isEmpty() ||artist.isEmpty() || genre.isEmpty())
                {
                    Toast.makeText(getApplicationContext(),"All fields are mandatory.", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    MusicInfo musicInfo = new MusicInfo(songname,artist,genre);
                    DatabaseHandler db = new DatabaseHandler(AddSong.this);
                    db.addSong(musicInfo);
                    finish();
                }
            }
        });


    }
}
